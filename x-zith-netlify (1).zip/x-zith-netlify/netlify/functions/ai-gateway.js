// netlify/functions/ai-gateway.js
//
// Netlify serverless function that proxies AI and search API calls.
// All secret keys (Gemini, DeepSeek, OpenRouter, SerpAPI) live in
// Netlify environment variables ONLY — they never touch the browser.
//
// The browser sends { action, prompt/query } and gets back { text/html }.

const handler = async (event) => {
  if (event.httpMethod === "OPTIONS") {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
      },
    };
  }

  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method not allowed" }),
      headers: { "Content-Type": "application/json" },
    };
  }

  const ok = (body) => ({
    statusCode: 200,
    headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  const err = (msg, status = 500) => ({
    statusCode: status,
    headers: { "Access-Control-Allow-Origin": "*", "Content-Type": "application/json" },
    body: JSON.stringify({ error: msg }),
  });

  let body;
  try {
    body = JSON.parse(event.body);
  } catch {
    return err("Invalid JSON body", 400);
  }

  const { action, prompt = "", query = "" } = body;

  try {
    switch (action) {
      case "gemini":
        return ok({ text: await callGemini(prompt) });
      case "openrouter":
        return ok({ text: await callOpenRouter(prompt) });
      case "deepseek":
        return ok({ text: await callDeepseek(prompt) });
      case "search":
        return ok({ html: await callSearch(query) });
      default:
        return err(`Unknown action: ${action}`, 400);
    }
  } catch (e) {
    console.error("ai-gateway error:", e);
    return err(e.message || String(e));
  }
};

// ── Gemini ────────────────────────────────────────────────────────────────
async function callGemini(prompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("GEMINI_API_KEY not set in Netlify environment");

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
    }
  );

  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || "Gemini request failed");
  return data.candidates[0].content.parts[0].text;
}

// ── OpenRouter (free Llama 3 — fallback) ─────────────────────────────────
async function callOpenRouter(prompt) {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) throw new Error("OPENROUTER_API_KEY not set in Netlify environment");

  const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model: "meta-llama/llama-3-8b-instruct:free",
      messages: [{ role: "user", content: prompt }],
    }),
  });

  const data = await res.json();
  if (!res.ok) throw new Error(data?.error?.message || "OpenRouter request failed");
  return data.choices[0].message.content;
}

// ── DeepSeek (falls back to OpenRouter on any failure) ────────────────────
async function callDeepseek(prompt) {
  const key = process.env.DEEPSEEK_API_KEY;
  if (!key) return callOpenRouter(prompt);

  try {
    const res = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${key}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      console.log("DeepSeek failed, falling back to OpenRouter");
      return callOpenRouter(prompt);
    }

    const data = await res.json();
    return data.choices[0].message.content;
  } catch (e) {
    console.log("DeepSeek error, falling back to OpenRouter:", e.message);
    return callOpenRouter(prompt);
  }
}

// ── SerpAPI (with Gemini video link fallback) ────────────────────────────
function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

async function callSearch(query) {
  const key = process.env.SERPAPI_KEY;

  if (key) {
    try {
      const res = await fetch(
        `https://serpapi.com/search.json?q=${encodeURIComponent(query)}&api_key=${key}&engine=google`
      );
      const data = await res.json();

      const results = (data.organic_results || [])
        .slice(0, 5)
        .map((item) => `- <b>${escapeHtml(item.title)}</b>: <a href="${item.link}" target="_blank">${item.link}</a>`);

      if (results.length) return results.join("<br>");
    } catch (e) {
      console.log("SerpAPI failed, falling back to Gemini");
    }
  }

  // Fallback: ask Gemini to generate YouTube search links
  const text = await callGemini(
    `Give me 5 YouTube video search URLs for '${query}'. Format as: [Title](https://www.youtube.com/results?search_query=TERM)`
  );
  return text.replace(/\n/g, "<br>");
}

exports.handler = handler;
