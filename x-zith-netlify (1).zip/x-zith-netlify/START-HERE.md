# 🚀 X-ZITH Learning Hub — START HERE

You have a complete, production-ready learning platform. Here's how to launch it in 15 minutes.

---

## What You Have

✅ **index.html** — Your learning app UI (runs on Netlify)
✅ **netlify/functions/ai-gateway.js** — API proxy (holds your secret keys safely)
✅ **Supabase database** — Stores users, quizzes, scores, leaderboards
✅ **All AI providers** — Gemini, DeepSeek, OpenRouter, SerpAPI
✅ **Complete feature set** — Textbook generator, quizzes (20s timer), past questions, AI tutor, web search, leaderboard, badges

---

## The 3-Step Launch

### Step 1️⃣: Supabase Setup (5 minutes)

1. **Go to https://supabase.com** and create a free project
2. **Copy your Project URL and Anon Key**
3. **Update index.html:**
   ```javascript
   // Line ~240 (search for SUPABASE_URL)
   const SUPABASE_URL  = "https://YOUR_PROJECT_URL.supabase.co";
   const SUPABASE_KEY  = "YOUR_ANON_KEY";
   ```
4. **Go to Supabase SQL Editor and run all the SQL from `SUPABASE-SETUP.md`**
   (This creates users, activity, and cache tables)

✓ **Supabase is ready**

---

### Step 2️⃣: Netlify Deployment (5 minutes)

**Option A: GitHub (auto-deploys on every push)**
1. **Upload this folder to GitHub**
2. **Go to https://app.netlify.com → "Import an existing project"**
3. **Connect your GitHub repo** → Deploy
4. **Done!** Netlify gives you a live URL

**Option B: Drag & Drop (instant)**
1. **Zip this entire folder**
2. **Go to https://app.netlify.com → "Deploy manually"**
3. **Drag the zip onto Netlify**
4. **Done!** Live in seconds

You now have a live app at `https://your-site-name.netlify.app`

✓ **App is deployed**

---

### Step 3️⃣: Add Your API Keys (3 minutes)

1. **In Netlify dashboard → "Site settings" → "Environment"**
2. **Add these 4 environment variables:**

   | Variable Name | Your Value |
   |--------------|-----------|
   | `GEMINI_API_KEY` | (paste your Gemini key) |
   | `DEEPSEEK_API_KEY` | (paste your DeepSeek key) |
   | `OPENROUTER_API_KEY` | (paste your OpenRouter key) |
   | `SERPAPI_KEY` | (paste your SerpAPI key) |

3. **Click "Save"**
4. **Redeploy** (GitHub auto-deploys, or Netlify manual = click "Deploys" → redeploy)

✓ **APIs are live**

---

## Test It

1. **Open your Netlify URL** (e.g., `https://my-app.netlify.app`)
2. **You should see the X-ZITH splash screen for 3 seconds**, then the landing page
3. **Click "Get Started" → Sign up with any email/password**
4. **You should immediately get the "Welcome Aboard" badge**
5. **Go to Dashboard → see your profile with 0 points**
6. **Try a quiz:**
   - Click "Textbook & Quiz"
   - Select JSS → Mathematics → "Fractions"
   - Click "Generate Note"
   - Click "Start Timed Quiz (5 Questions · 20s each)"
   - Answer a question (you have 20 seconds)
   - Get +5 points

✓ **Everything works**

---

## What Happens After Launch

### Students can:
- 📖 **Generate unlimited textbooks** on any topic (free)
- 📝 **Take timed quizzes** (5 questions, 20 seconds per question)
- 🎯 **Complete daily challenges** (1 free question per day)
- 📝 **Practice past questions** (60 WAEC/NECO/JAMB questions across 6 levels)
- 🤖 **Chat with AI Fixto** (24/7 study buddy with voice input/playback)
- 🌐 **Search YouTube & articles** for any topic
- 🏆 **Compete on leaderboard** and earn 7 badges (0 pts → 10,000 pts)

### Teachers can:
- Monitor student progress via the leaderboard
- See which topics students struggle with (from activity logs)
- Share the link with your class → students sign up immediately

---

## How Sign-Up Works

**When a student clicks "Sign Up":**

1. They enter: Username, Email, Password (6+ chars)
2. Password is hashed in the browser (SHA-256)
3. Data goes to Supabase and is stored in the `users` table
4. They automatically get the "Welcome Aboard" badge
5. They can immediately log in

**No email verification needed** (it's a learning app, not a bank account).

---

## Where Are My API Keys?

🔒 **They're ONLY in Netlify environment variables.**

- **NOT in the code** (index.html has zero API keys)
- **NOT in the repo** (if you pushed to GitHub)
- **ONLY accessible to the Netlify Function** (`ai-gateway.js`)
- **Completely hidden from students** (they can't see them even in browser DevTools)

If a key leaks, rotate it in Netlify in 1 minute:
1. Netlify → Site Settings → Environment
2. Update the variable
3. Redeploy

---

## Customization Tips

### Change the splash screen timer
In `index.html`, line ~900:
```javascript
setTimeout(()=>showView("view-landing"),3000);  // 3000ms = 3 seconds
// Change 3000 to any milliseconds (e.g., 5000 = 5 seconds)
```

### Change quiz timer (currently 20 seconds per question)
In `index.html`, search for `startTimer(t,20,...)` and change the second number:
```javascript
startTimer(t,30,...)  // 30 seconds per question
```

### Add your school logo
Replace `assets/logo.png` with your own 1:1 square image

### Change colors
Search for `#1f8ef1` (blue) in `index.html` and replace with your brand color

---

## Troubleshooting

| Problem | Solution |
|---------|----------|
| **Splash screen doesn't appear** | It's showing for 3s. If you don't see landing page after, check console (F12 → Console) for errors |
| **Sign-up fails** | Check that Supabase SQL tables were created. Run the SQL from `SUPABASE-SETUP.md` again |
| **"Gateway error" when taking a quiz** | Your Netlify Function isn't deployed. Check Netlify Functions → ai-gateway logs |
| **"GEMINI_API_KEY not set" error** | You didn't add environment variables in Netlify. Follow Step 3 above |
| **Quizzes never load** | Check Netlify Function logs (Site Dashboard → Functions → ai-gateway) |

---

## Next Steps

1. **Read `NETLIFY-SETUP.md`** for detailed deployment steps
2. **Read `SUPABASE-SETUP.md`** for database details
3. **Share your URL with students** — they can sign up and start learning immediately
4. **Monitor the leaderboard** to see who's engaged

---

## Your App Is Now Live 🎉

Students can access it from:
- 🖥️ Desktop browser
- 📱 Mobile browser
- 📱 Android app (if you wrap it with React Native later)
- 🍎 iOS app (if you wrap it with Swift later)

**It works everywhere.**

---

## Questions?

All the docs are in this folder:
- `NETLIFY-SETUP.md` — Deployment details
- `SUPABASE-SETUP.md` — Database tables & security
- `index.html` — The full app code (well-commented)

Good luck! 🚀
