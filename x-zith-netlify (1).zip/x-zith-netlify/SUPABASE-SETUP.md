# X-ZITH Learning Hub — Supabase Database Setup

Your app stores user data, quizzes, scores, and leaderboards in Supabase.
The Netlify Function holds AI keys, but Supabase holds everything else.

---

## 1. Create Your Supabase Project

1. **Go to https://supabase.com**
2. **Sign in** (or create an account)
3. **Click "New project"**
4. **Fill in:**
   - Name: `x-zith-learning-hub`
   - Database password: (strong password, save it)
   - Region: (closest to your users, e.g., `Europe - Dublin`)
5. **Wait 2 minutes for the database to spin up**

---

## 2. Copy Your Supabase URL and Key

1. **Go to Settings → API**
2. **Copy these two values:**
   - **Project URL:** `https://xxxxxx.supabase.co`
   - **Anon key:** `eyJhbG...` (starts with eyJ)

3. **Paste them into `index.html`:**
   ```javascript
   const SUPABASE_URL  = "https://YOUR_PROJECT_URL.supabase.co";
   const SUPABASE_KEY  = "YOUR_ANON_KEY";
   ```

---

## 3. Create Database Tables

Go to **SQL Editor** in Supabase and run this full SQL script:

```sql
-- ============================================================
-- USERS TABLE (stores student/teacher accounts)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
  email text PRIMARY KEY,
  username text NOT NULL,
  password_hash text NOT NULL,
  total_score int DEFAULT 0,
  quizzes_taken int DEFAULT 0,
  exam_questions int DEFAULT 0,
  streak int DEFAULT 1,
  last_active date,
  last_daily_challenge date,
  badges_earned text DEFAULT '',
  unseen_badges text DEFAULT '',
  created_at timestamp DEFAULT NOW()
);

-- ============================================================
-- ACTIVITY TABLE (stores each quiz/exam attempt for history)
-- ============================================================
CREATE TABLE IF NOT EXISTS activity (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  username text,
  type text,         -- "Quiz", "WAEC", "NECO", "JAMB", "Daily Challenge"
  details text,      -- "Quiz: Photosynthesis", "WAEC Physics L1", etc.
  points int DEFAULT 0,
  timestamp text,
  FOREIGN KEY (username) REFERENCES users(email)
);

-- ============================================================
-- GENERATED CACHE TABLE (stores AI-generated quizzes to avoid recomputation)
-- ============================================================
CREATE TABLE IF NOT EXISTS generated_cache (
  cache_id text PRIMARY KEY,
  content text,
  timestamp text
);

-- ============================================================
-- ENABLE ROW-LEVEL SECURITY (RLS) to protect user data
-- ============================================================

-- Users table policies
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Allow anyone to sign up (insert their own record)
CREATE POLICY "allow_public_signup" ON users
  FOR INSERT
  WITH CHECK (true);

-- Allow users to read only their own data
CREATE POLICY "users_can_read_own_data" ON users
  FOR SELECT
  USING (email = CURRENT_USER);

-- Allow users to update only their own data
CREATE POLICY "users_can_update_own_data" ON users
  FOR UPDATE
  USING (email = CURRENT_USER)
  WITH CHECK (email = CURRENT_USER);

-- Activity table policies (read-only for users, append-only)
ALTER TABLE activity ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone_can_insert_activity" ON activity
  FOR INSERT
  WITH CHECK (true);

CREATE POLICY "anyone_can_read_activity" ON activity
  FOR SELECT
  USING (true);

-- Cache table (read-only)
ALTER TABLE generated_cache ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anyone_can_read_cache" ON generated_cache
  FOR SELECT
  USING (true);

CREATE POLICY "anyone_can_insert_cache" ON generated_cache
  FOR INSERT
  WITH CHECK (true);
```

---

## 4. Verify Tables Were Created

1. **Go to SQL Editor** again
2. **Run this:**
   ```sql
   SELECT table_name FROM information_schema.tables 
   WHERE table_schema = 'public';
   ```

You should see:
- `users`
- `activity`
- `generated_cache`

---

## 5. Test Your Supabase Connection

In `index.html`, open the browser console (F12 → Console) and run:

```javascript
// Test if Supabase connection works
await sb.from("users").select("*").limit(1);
```

If no error appears, your Supabase setup is correct.

---

## How Each Table Works

### `users` — Student/Teacher Accounts
| Column | Type | Purpose |
|--------|------|---------|
| `email` | text | Unique login identifier (primary key) |
| `username` | text | Display name in the app |
| `password_hash` | text | SHA-256 hashed password (never store plain text) |
| `total_score` | int | Sum of all points earned |
| `quizzes_taken` | int | Count of completed quizzes |
| `exam_questions` | int | Count of past questions answered (out of 60) |
| `streak` | int | Consecutive days of activity |
| `last_active` | date | Last date they used the app |
| `last_daily_challenge` | date | Last date they completed daily challenge |
| `badges_earned` | text | Comma-separated list of badge IDs (e.g., "1,2,3,5") |
| `unseen_badges` | text | Comma-separated list of new badges to notify |

**Example record:**
```json
{
  "email": "chiamaka@example.com",
  "username": "Chiamaka Obi",
  "password_hash": "5e4ecc....",
  "total_score": 1250,
  "quizzes_taken": 8,
  "exam_questions": 15,
  "streak": 7,
  "last_active": "2026-08-25",
  "badges_earned": "1,2,3",
  "unseen_badges": "3"
}
```

### `activity` — Quiz/Exam History
Every time a student takes a quiz or exam, a record is inserted:

| Column | Example |
|--------|---------|
| `username` | `chiamaka@example.com` |
| `type` | `Quiz` or `WAEC` or `NECO` or `JAMB` or `Daily Challenge` |
| `details` | `Quiz: Photosynthesis` or `WAEC Physics Level 3` |
| `points` | `5` (points earned) |
| `timestamp` | `2026-08-25 14:23:45` |

**Used for:** Leaderboard, recent activity on profile, trends.

### `generated_cache` — Reusable Quiz Content
When Gemini/DeepSeek generates a quiz on "Photosynthesis for JSS", we cache it
so the next student asking doesn't spend API money regenerating the same quiz.

| Column | Example |
|--------|---------|
| `cache_id` | `a7f3e2c1f8d...` (MD5 hash of the prompt) |
| `content` | `[{"q":"What is...","options":{...}},...]` (full JSON quiz) |
| `timestamp` | `2026-08-20` |

**Expires:** Never (but you can manually delete old entries to save space).

---

## Updating Supabase Data Later

### Add a new column
```sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS new_column text DEFAULT '';
```

### Delete a student's account
```sql
DELETE FROM users WHERE email = 'student@example.com';
```

### View all students
```sql
SELECT email, username, total_score FROM users ORDER BY total_score DESC;
```

### View leaderboard (top 10)
```sql
SELECT username, total_score FROM users ORDER BY total_score DESC LIMIT 10;
```

### Clear cache (if storage is getting full)
```sql
DELETE FROM generated_cache WHERE timestamp < '2026-08-01';
```

---

## Password Security

⚠️ **Important:** Passwords are hashed with SHA-256 in the browser before being sent to Supabase.

**Never** do this in production:
- Store plain-text passwords
- Compare passwords client-side
- Rely only on client-side hashing

This app's approach (client-side SHA-256 hash) is simple but not production-grade. For a real app with sensitive data:
- Use Supabase Auth (built-in authentication)
- Or use bcrypt/argon2 hashing server-side

For now, it's good enough for a student learning app.

---

## Row-Level Security Explained

The `CREATE POLICY` statements above ensure:

1. **Students can only sign up once** → `allow_public_signup`
2. **Students can't see other students' data** → `users_can_read_own_data`
3. **Students can't edit other students' scores** → `users_can_update_own_data`
4. **Activity is public** (for leaderboards) → `anyone_can_read_activity`
5. **Cached quizzes are public** (for reuse) → `anyone_can_read_cache`

If you need to debug permissions issues, check the **SQL Editor → Policy auditing** logs.

---

## Troubleshooting

### "users table not found"
- You didn't run the SQL script above
- Run it again in SQL Editor

### "Anon key can't insert into users"
- RLS policies aren't set up
- Re-run the `CREATE POLICY` statements above

### "Column not found" when signing up
- Your table structure is different
- Check that your `users` table has: email, username, password_hash
- Run the SQL script again to recreate it

### Storage getting full?
- Check `SELECT pg_size_pretty(pg_total_relation_size('generated_cache'));`
- If large, clear old cache: `DELETE FROM generated_cache WHERE timestamp < '2026-08-01';`

---

## Backup Your Data

1. **Weekly backups:** Supabase does this automatically
2. **Manual backup:** SQL Editor → Export (top right)
3. **Download data:**
   ```sql
   COPY (SELECT * FROM users) TO STDOUT CSV;
   ```

---

## You're all set!

Your Supabase database is now ready. Students can sign up, take quizzes, earn points, and compete on leaderboards.
