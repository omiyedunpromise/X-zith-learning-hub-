# X-ZITH Learning Hub — Netlify Deployment Guide

## What changed

✅ **HTML hosting** → Netlify (instead of a local server)
✅ **API proxy** → Netlify Functions (instead of Supabase Edge Functions)
✅ **Splash timer** → Now shows for 3 seconds before opening the app
✅ **Sign-up** → Works exactly the same (still uses Supabase for user auth)

You still use Supabase for:
- User login/signup
- Storing quizzes, past questions, scores, badges
- Storing activity history and leaderboards

But all AI and search calls now route through a Netlify Function on your own domain.

---

## Step 1: Deploy to Netlify

### Option A: GitHub (recommended — auto-deploys on each push)

1. **Push your code to GitHub:**
   ```bash
   git init
   git add .
   git commit -m "X-ZITH Learning Hub"
   git remote add origin https://github.com/YOUR_USERNAME/x-zith-app.git
   git push -u origin main
   ```

2. **Log in to Netlify:** https://app.netlify.com

3. **Click "Add new site" → "Import an existing project"**

4. **Connect your GitHub repo** and authorize Netlify

5. **Build settings:**
   - Build command: *(leave empty)*
   - Publish directory: `.` (current folder)

6. **Click "Deploy site"**

Netlify will give you a URL like `https://your-site-name.netlify.app` — that's your live app.

### Option B: Drag and drop (faster for testing)

1. **Create a folder with:**
   ```
   index.html
   netlify.toml
   netlify/
     functions/
       ai-gateway.js
   assets/
     logo.png
     hero1.jpg
     hero2.jpg
   ```

2. **Zip the folder**

3. **Go to https://app.netlify.com → "Add new site" → "Deploy manually"**

4. **Drag and drop the zip file**

Netlify will deploy it instantly.

---

## Step 2: Set Your API Keys in Netlify

**NEVER put API keys in any file you upload.** Set them in the Netlify dashboard instead.

1. **Go to your Netlify site dashboard**

2. **Left sidebar → "Site settings" → "Build & deploy" → "Environment"**

3. **Click "Edit variables"**

4. **Add 4 new variables:**

   | Name | Value |
   |------|-------|
   | `GEMINI_API_KEY` | `AIzaSy...` (your real Gemini key) |
   | `DEEPSEEK_API_KEY` | `sk-a5e6...` (your real DeepSeek key) |
   | `OPENROUTER_API_KEY` | `sk-or-v1-...` (your real OpenRouter key) |
   | `SERPAPI_KEY` | `238c147...` (your real SerpAPI key) |

5. **Click "Save"**

6. **Redeploy** (or push to GitHub and let Netlify auto-redeploy)

   The Netlify Function at `/.netlify/functions/ai-gateway` will now have access to these keys.

---

## Step 3: Verify the Setup

**Test the function:**
```bash
curl -X POST https://your-site-name.netlify.app/.netlify/functions/ai-gateway \
  -H "Content-Type: application/json" \
  -d '{"action":"gemini","prompt":"Say hello in one sentence."}'
```

You should get back:
```json
{"text":"Hello! How can I help you today?"}
```

If you get an error about missing keys, you didn't set the environment variables correctly. Double-check in the Netlify dashboard.

---

## Step 4: Supabase Setup (Still Needed!)

You still need Supabase for user authentication and data. Follow these steps:

### Create the required tables:

In your Supabase SQL editor, run these commands:

```sql
-- Users table
CREATE TABLE IF NOT EXISTS users (
  email text primary key,
  username text not null,
  password_hash text not null,
  total_score int default 0,
  quizzes_taken int default 0,
  exam_questions int default 0,
  streak int default 1,
  last_active date,
  last_daily_challenge date,
  badges_earned text default '',
  unseen_badges text default ''
);

-- Activity (for leaderboard history)
CREATE TABLE IF NOT EXISTS activity (
  id bigint generated always as identity primary key,
  username text,
  type text,
  details text,
  points int default 0,
  timestamp text
);

-- Generated content cache (quizzes, textbooks)
CREATE TABLE IF NOT EXISTS generated_cache (
  cache_id text primary key,
  content text,
  timestamp text
);
```

### Enable Supabase Auth (Row Level Security):

In Supabase, go to **Authentication → Policies** and make sure your `users` table allows:
- Anyone to insert their own signup record
- Users to read their own records
- Users to update their own records

Or manually create these policies in SQL:

```sql
-- Allow anyone to sign up (insert)
CREATE POLICY "allow_signup" ON users
  FOR INSERT WITH CHECK (true);

-- Allow users to see only their own data
CREATE POLICY "user_can_read_own" ON users
  FOR SELECT USING (auth.uid()::text = email);

-- Allow users to update their own data
CREATE POLICY "user_can_update_own" ON users
  FOR UPDATE USING (auth.uid()::text = email);
```

---

## How Sign-Up Works

### The Process:

1. **User enters username, email, password** in the sign-up form
2. **Password is hashed** (SHA-256) in the browser
3. **Data is sent to Supabase** and stored in the `users` table
4. **User gets the "Welcome Aboard" badge** (badge #1 automatically)
5. **User is redirected to login**

### What makes it secure:

- Passwords are **hashed before** leaving the browser (never sent in plain text)
- Supabase's **Row Level Security** ensures users can only see their own data
- The browser never stores the password (only the hash is stored in Supabase)
- Each login re-hashes the entered password and compares it to the stored hash

### Important:

- **Usernames** don't have to be unique (but emails do)
- **Email must be valid** (no format checking server-side, but Supabase will reject duplicates)
- **Password must be 6+ characters**
- **Once signed up**, user can immediately log in with email + password

---

## Splash Screen Timing

The splash screen now shows for **exactly 3 seconds** before the app opens automatically.

The timer is in `index.html`:
```javascript
setTimeout(()=>showView("view-landing"),3000);  // 3000ms = 3 seconds
```

If you want to change it later, edit that one number.

---

## Updating Your API Keys

If you need to rotate a key (e.g., Gemini key leaked):

1. **Go to Netlify Site Settings → Environment**
2. **Edit the variable** (e.g., `GEMINI_API_KEY`)
3. **Paste the new key**
4. **Click Save**
5. **Redeploy** (manually, or GitHub auto-deploys)

The Netlify Function will use the new key on the next request.

---

## Troubleshooting

### "Gateway error" or "Unknown action" in the app

- Check that `netlify.toml` is in the root folder
- Check that `netlify/functions/ai-gateway.js` exists
- Check Netlify Function logs: Site Dashboard → Functions → ai-gateway (click to see logs)

### "GEMINI_API_KEY not set" error

- You didn't add the environment variable in Netlify dashboard
- You added it but forgot to redeploy
- Check capitalization — must be exactly `GEMINI_API_KEY`

### Sign-up fails with "Email already registered"

- The email already exists in your Supabase `users` table
- Try a different email address

### "Supabase connection failed"

- Your Supabase URL or key is wrong
- Double-check `SUPABASE_URL` and `SUPABASE_KEY` in `index.html`
- Make sure your Supabase project is not paused

---

## Your Netlify URL

Once deployed, your app will be at:
```
https://your-site-name.netlify.app
```

Share this link with students and teachers!

---

## One last thing: Keep your Supabase key safe

The Supabase key in `index.html` is the public/anon key — it's safe to be visible. But protect:
- Your Supabase **project URL**
- Your Supabase **service role key** (never put this anywhere public)

The service role key is in Supabase Settings → API — keep that secret.
